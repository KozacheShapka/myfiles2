Установка плагина.

1. Распакуйте архив
2. Скопируйте папку плагина в папку AIMP\Plugins
3. Откнойте Настройки >> Плагины, найдите плагин и включите его (можно просто перезапустить AIMP)
4. Пользуйтесь

Описание:
Показывает в Discord, что вы слушаете в AIMP

Код:
https://github.com/Exle/AIMP-Discord-Presence

Изменения:
	v1.0.0.2 (1f38cca):
		Исправлено зависание AIMP при выключении / перезапуске
	
	v1.0.0.3 (e3583a1):
		Исправлены ошибки при закрытии AIMP
	
	v1.0.0.4 (4faebc1):
		Исправлено, после перезапуска Discord не отображался статус
		Добавлено изображение при прослушивании url
		Мелкие исправления
		
	v1.0.0.5 (dddf7e4):
		Исправлено https://github.com/Exle/AIMP-Discord-Presence/issues/1

	v1.0.0.6 (c65697c):
		Исправлено https://github.com/Exle/AIMP-Discord-Presence/issues/5
		Исправлено https://github.com/Exle/AIMP-Discord-Presence/issues/6

	v1.0.0.7 (07d4dd5):
		Исправлено https://github.com/Exle/AIMP-Discord-Presence/issues/6

	v1.0.0.8 (b2e4229):
		Восстановлена работа плагина
		Прочие исправления
	
	v1.0.0.9 (42ba79e):
		Исправлено https://github.com/Exle/AIMP-Discord-Presence/issues/18
		Исправлено https://www.aimp.ru/forum/index.php?topic=59461.msg398374#msg398374