﻿Установка плагина.

1. Распакуйте архив
2. Скопируйте папку плагина в папку AIMP\Plugins
3. Откнойте Настройки >> Плагины, найдите плагин и включите его (можно просто перезапустить AIMP)
4. Пользуйтесь


SoundCloud support for AIMP.

Features:
+ User likes
+ User stream
+ User tracks and playlists (including private)
+ Custom urls (users, tracks, playlists, recommendations)
+ Multi-language support
+ Song exclusions (useful for stream)
+ Recommendations
+ Automatically loads new items (playlists, likes, stream, user's tracks, all custom urls)
+ Close integration with AIMP:
 - Local and global shortcuts
 - Delete current song from disk = Unlike and add to exclusions
 - Add to bookmarks = Like
+ Can load multiple SoundCloud playlists to one AIMP playlist (with grouping enabled in AIMP)
+ Open source

Changelog
v1.0
- Loading artwork images
- Drag&Drop support
- Open file location
- Copy file to clipboard
- Bug fixes
- Exclusions manager
v0.19
- Added Repost button
v0.18
- Fixed adding URLs without SoundCloud account
- Fixes in Ukrainian language.
v0.17
- Fixed loading all user tracks
- Fixed memory leak in Audio Converter and Advanced Tag Editor
- Added languages: Eesti, Español (Argentina) and Ukrainian.
v0.16
- Added option for including song uploader username in the title
- Added support for /explore and /tags URLs
v0.15
- Added Czech translation (thanks R3gi!)
- Fixed action names in AIMP Hot Keys options
- Options dialog items are now resizing correctly to different translations
- Minor fixes and improvements
v0.14
- Minor fixes and improvements
v0.13
- Fixed memory leak in HTTP requests
v0.12
- Added version information in the options dialog
v0.11
- Connect button is now translatable
- Added Russian language (thanks to Долматов Алексей!)
v0.1
- Initial release

Translations are of course welcome :)

I created this plugin because I like SoundCloud and I use it on a daily basis, but there are some downsides of listening music in web browser. You need to look for the right tab when you want to stop/pause/like/play next track. With AIMP, every action can be on global shortcut so it's much faster. There is also one thing that SoundCloud lacks and that are song exclusions. Stream and recommendations are great but when some song is completely not in my taste, there is no way to permanently hide it from stream or recommendations. Making plugin for AIMP solved all my problems :)

It is not yet tested on every possible use case so please report any bugs you encounter.

I'm looking forward to your feedback :)

Code can be found at https://github.com/AdrianEddy/AIMPSoundcloud